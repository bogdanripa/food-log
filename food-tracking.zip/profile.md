# {{USER_NAME}} — Profile

This file is the canonical profile for {{USER_NAME}}, shared across skills. Skills should read it (not duplicate it) when they need personal context.

**Location**: `/mnt/skills/user/food-log/profile.md`

## Identity

- **Name**: {{USER_NAME}}
- **Date of birth**: {{USER_DOB}}
- **Lives in**: {{USER_CITY}}, {{USER_COUNTRY}}
- **Timezone**: {{USER_TIMEZONE}}
- **Languages**: {{USER_LANGUAGES}} — when responding, default to whichever language {{USER_NAME}} is currently using.

## Family

{{FAMILY_BLOCK}}
<!-- Edit or remove. Example structure:
- **Spouse**: [Name] — they usually have dinner together
- **Children**:
  - [Name] (b. YYYY)
  - [Name] (b. YYYY)
-->

## Physical stats

- **Height**: {{USER_HEIGHT_CM}} cm
- **Weight**: {{USER_WEIGHT_KG}} kg
- **BMI**: {{USER_BMI}}
- **Exercise**: {{USER_EXERCISE}}

## Derived nutrition baselines

Computed using Mifflin-St Jeor (the standard BMR equation) + a {{USER_ACTIVITY_MULTIPLIER}} activity multiplier.

> ⚠️ Estimates. Re-derive if weight, height, or activity level changes meaningfully.

- **BMR** (resting energy): ~{{USER_BMR}} kcal/day
- **TDEE** (maintenance calories): ~{{USER_TDEE}} kcal/day
- **Maintenance window**: {{USER_TDEE_LOW}}–{{USER_TDEE_HIGH}} kcal/day

### Default macro targets

- **Protein**: ~{{USER_PROTEIN_LOW}}–{{USER_PROTEIN_HIGH}} g/day
- **Fats**: ~{{USER_FAT_LOW}}–{{USER_FAT_HIGH}} g/day
- **Carbs**: the rest (~{{USER_CARB_LOW}}–{{USER_CARB_HIGH}} g/day)

## How skills should use this

- Read this file when personal context is relevant.
- Nutrition numbers are frames, not rules.
- Don't moralize about deviations. {{USER_NAME}} is driving.

## When to update

- Weight change (>3 kg) → recompute BMR/TDEE
- Activity change → update multiplier
- New long-term context (allergies, dietary preferences) — add here
