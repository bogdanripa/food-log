# Macro Estimation Reference

A reference for estimating macros when logging meals. Numbers are rounded — this is a tracking tool, not a lab measurement. Round macros to whole grams and calories to the nearest 10.

> **General principle**: when in doubt about dish identity or portion size, ask. When in doubt about exact macros for a clearly identified dish, estimate confidently and log — {{USER_NAME}} can correct via `update` if needed.

> **Sugars convention**: the `Sugars` column tracks **total sugars** (EU nutrition-label convention), which includes naturally occurring sugars like lactose in milk and fructose in fruit, not only added sugars. The lookup tables below already follow this convention.

> **Lactose-free milk**: depending on processing, total sugars may be lower than regular milk — not equal. Two methods:
> - **Enzyme-only** (lactase added): lactose is split into glucose + galactose; **total sugars stay the same** (~5g/100ml whole). Same calories.
> - **Enzyme + ultrafiltration**: some lactose is filtered out before the enzyme step; **total sugars come out lower** (~3g/100ml whole instead of ~5g). Slightly lower calories.
>
> **Don't assume.** If {{USER_NAME}} logs lactose-free milk and the macros matter, ask which brand or check a label. If unknown, default to the same numbers as regular milk for the relevant fat content.

## Portion-size visual cues

- **Plate diameter**: standard dinner plate ~25 cm; bistro/lunch plate ~22 cm
- **Wine glass**: standard pour ~150 ml
- **Beer**: bottle 330 ml; large bottle 500 ml; pint 500 ml; small draft 300 ml; standard draft 500 ml
- **Coffee**: espresso 30 ml; double espresso 60 ml; cappuccino 150-180 ml; latte 240 ml; americano 200-300 ml
- **Spirits**: standard shot 50 ml; cocktail 200-300 ml total liquid
- **Steak**: a typical restaurant ribeye is 250-350 g raw; tagliata or smaller cuts 180-220 g
- **Pasta dish**: restaurant portion ~80-120 g dry pasta + sauce → 350-500 g cooked

## Drinks — quick lookup

| Drink | Portion | C / P / F / Sugar / kcal |
|---|---|---|
| Espresso | 30 ml | 0 / 0 / 0 / 0 / 5 |
| Double espresso | 60 ml | 1 / 0 / 0 / 0 / 10 |
| Americano | 250 ml | 1 / 0 / 0 / 0 / 10 |
| Cappuccino (whole milk) | 180 ml | 6 / 4 / 4 / 6 / 80 |
| Latte (whole milk) | 240 ml | 12 / 8 / 7 / 12 / 150 |
| Flat white | 180 ml | 8 / 6 / 5 / 8 / 110 |
| Tea (plain) | 250 ml | 0 / 0 / 0 / 0 / 2 |
| Tea with milk + 1 sugar | 250 ml | 6 / 1 / 1 / 6 / 35 |
| Beer, lager 0.33 L | 330 ml | 11 / 1 / 0 / 0 / 140 |
| Beer, lager 0.5 L | 500 ml | 17 / 2 / 0 / 0 / 215 |
| Beer, IPA 0.5 L | 500 ml | 18 / 2 / 0 / 0 / 240 |
| Beer, dark/stout 0.5 L | 500 ml | 22 / 3 / 0 / 0 / 260 |
| Red wine | 150 ml | 4 / 0 / 0 / 1 / 125 |
| White wine (dry) | 150 ml | 4 / 0 / 0 / 1 / 120 |
| Rosé | 150 ml | 4 / 0 / 0 / 2 / 125 |
| Champagne / sparkling | 120 ml | 4 / 0 / 0 / 2 / 90 |
| Whisky / vodka / gin / rum | 50 ml | 0 / 0 / 0 / 0 / 110 |
| Tuică / palincă | 50 ml | 0 / 0 / 0 / 0 / 130 |
| Aperol spritz | 200 ml | 18 / 0 / 0 / 16 / 175 |
| Mojito | 250 ml | 22 / 0 / 0 / 20 / 200 |
| Coca-Cola | 330 ml | 35 / 0 / 0 / 35 / 140 |
| Orange juice | 250 ml | 26 / 2 / 0 / 22 / 110 |
| Smoothie (typical) | 350 ml | 50 / 5 / 2 / 40 / 230 |
| Sparkling / still water | any | 0 / 0 / 0 / 0 / 0 |

## Romanian dishes — common entries

{{USER_NAME}} lives in Bucharest; Romanian dishes are likely to come up.

| Dish | Typical portion | C / P / F / Sugar / kcal |
|---|---|---|
| Mici (5-6 pieces, ~250 g) | with mustard | 5 / 35 / 45 / 1 / 580 |
| Mici (3 pieces) | starter portion | 3 / 20 / 25 / 0 / 320 |
| Mici cu cartofi prăjiți | 5 mici + ~200g fries | 50 / 40 / 65 / 1 / 920 |
| Sarmale (4 rolls) | with mămăliga + smântână | 50 / 30 / 35 / 8 / 620 |
| Mămăligă cu brânză și smântână | ~300g | 60 / 18 / 25 / 4 / 510 |
| Ciorbă de burtă | ~400 ml + smântână | 12 / 14 / 18 / 4 / 250 |
| Ciorbă de perișoare | ~400 ml | 18 / 16 / 10 / 5 / 220 |
| Ciorbă rădăuțeană | ~400 ml | 12 / 22 / 14 / 5 / 250 |
| Tochitură (with polenta + egg) | ~350 g | 50 / 35 / 45 / 4 / 720 |
| Schnitzel (pork, ~180 g) | with fries | 70 / 35 / 40 / 2 / 760 |
| Pomana porcului | ~300 g | 8 / 30 / 50 / 2 / 600 |
| Salată orientală | ~250 g | 30 / 6 / 12 / 6 / 250 |
| Salată de boeuf | ~250 g | 25 / 12 / 28 / 5 / 400 |
| Papanași (cu smântână și dulceață) | 1 portion | 60 / 14 / 30 / 35 / 580 |
| Cozonac (1 slice) | ~80 g | 38 / 6 / 12 / 18 / 290 |

## International dishes — common entries

| Dish | Typical portion | C / P / F / Sugar / kcal |
|---|---|---|
| Caesar salad with grilled chicken | restaurant portion | 18 / 38 / 22 / 4 / 450 |
| Greek salad (no protein) | ~300 g | 12 / 8 / 22 / 8 / 280 |
| Tuna salad | ~300 g | 12 / 32 / 14 / 3 / 290 |
| Margherita pizza, 1 slice (1/8) | thin crust | 28 / 11 / 9 / 3 / 245 |
| Margherita pizza, whole | thin crust 30 cm | 220 / 90 / 70 / 25 / 1950 |
| Pepperoni pizza, 1 slice | thin crust | 30 / 13 / 12 / 3 / 285 |
| Pasta carbonara | restaurant portion | 65 / 28 / 32 / 4 / 680 |
| Pasta bolognese | restaurant portion | 75 / 28 / 22 / 6 / 600 |
| Pasta arrabiata | restaurant portion | 70 / 14 / 10 / 5 / 480 |
| Risotto (mushroom or vegetable) | ~350 g | 60 / 12 / 15 / 5 / 480 |
| Burger + fries | standard | 70 / 35 / 45 / 8 / 920 |
| Burger (just patty + bun) | no fries | 40 / 30 / 25 / 7 / 520 |
| Ribeye + fries | ~250g steak + ~200g fries | 50 / 45 / 50 / 3 / 850 |
| Ribeye + vegetables | ~250g steak | 25 / 50 / 38 / 5 / 680 |
| Grilled salmon + vegetables | ~180g salmon | 20 / 35 / 18 / 6 / 410 |
| Grilled chicken + quinoa | ~180g chicken + ~150g quinoa | 45 / 40 / 12 / 3 / 470 |
| Sushi (8-piece set, mixed) | maki + nigiri | 55 / 18 / 6 / 4 / 380 |
| Tuna sandwich | sliced bread + tuna | 45 / 28 / 16 / 4 / 420 |
| Club sandwich | with fries | 70 / 40 / 35 / 6 / 780 |
| Falafel wrap | with hummus + salad | 65 / 18 / 22 / 6 / 530 |

## Breakfast staples

| Item | Portion | C / P / F / Sugar / kcal |
|---|---|---|
| Croissant (plain) | 1 piece (~60g) | 30 / 5 / 15 / 8 / 280 |
| Pain au chocolat | 1 piece | 32 / 6 / 18 / 12 / 320 |
| Scrambled eggs (3 eggs) | with butter | 2 / 21 / 18 / 1 / 270 |
| Scrambled eggs + 2 toast | with butter | 30 / 25 / 18 / 3 / 380 |
| Greek yogurt (plain) | 200g | 8 / 18 / 6 / 7 / 160 |
| Greek yogurt + berries + honey | 200g + 50g berries | 25 / 15 / 5 / 18 / 220 |
| Oatmeal with banana | ~250g cooked | 55 / 10 / 6 / 18 / 320 |
| Avocado toast | 2 toasts + 1/2 avocado | 35 / 8 / 18 / 4 / 360 |

## Snacks & fruit

| Item | Portion | C / P / F / Sugar / kcal |
|---|---|---|
| Apple, medium | 1 piece (~180g) | 25 / 0 / 0 / 19 / 95 |
| Banana, medium | 1 piece | 27 / 1 / 0 / 14 / 105 |
| Orange | 1 medium | 15 / 1 / 0 / 12 / 65 |
| Pear | 1 medium | 25 / 0 / 0 / 17 / 100 |
| Almonds (handful, ~30g) | ~30 nuts | 6 / 6 / 14 / 1 / 170 |
| Mixed nuts (handful) | ~30g | 7 / 5 / 16 / 2 / 180 |
| Dark chocolate (70%) | 1 square ~10g | 4 / 1 / 4 / 3 / 60 |
| Yogurt cup | 125g | 10 / 5 / 3 / 10 / 90 |

## Hidden-calorie reminders

These commonly get under-counted:

- **Salad dressings**: Caesar/ranch dressing adds 100-200 kcal per portion
- **Olive oil drizzle**: 1 tbsp = 120 kcal, easy to miss
- **Butter on bread/vegetables**: 1 tbsp = 100 kcal
- **Cheese topping** on pasta: 30g parmesan = 110 kcal
- **Fried sides**: a side of fries adds 300-400 kcal to any main
- **Sauces**: pesto, aioli, hollandaise, beurre blanc all dense

If a dish is described as "with [sauce]" or "creamy", bump fats by 10-15g and calories by 100-150 vs. the same dish without.

## Beer / alcohol notation in the log

For consistency in `What`, prefer:
- `"0.33L beer"` or `"0.5L beer"` (not "a beer" or "beer bottle")
- `"glass of red wine"` / `"glass of white wine"` (assume 150 ml unless told otherwise)
- `"draft beer 0.5L"` if pulled from tap
- For multiple beers in one sitting, log as separate rows so each is countable
