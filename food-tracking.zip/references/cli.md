# `food_log.py` — CLI Reference

All operations go through `/mnt/skills/user/food-log/scripts/food_log.py`.

## `log` — Append a row

```bash
python3 .../food_log.py log \
  --when "2026-04-30 14:30" \
  --what "Caesar salad with grilled chicken" \
  --where "Ublo Bistro" \
  --meal-type "lunch" \
  --category "salad" \
  --carbs 25 --proteins 35 --fats 22 --sugars 4 --calories 480 \
  --photo /mnt/user-data/uploads/photo.jpg
```

Required: `--what`. Everything else is optional (defaults: `--when` is now, others empty).

The script:
- Uploads the photo (if given) to the `Food Log Photos` Drive folder (sets sharing to "anyone with the link can view")
- Appends one row to the sheet
- Returns the row number and Drive link as JSON

**Multiple rows from one photo**: call `log` once per row — pass the same `--photo` path each time and it will be re-used (the script caches uploaded file IDs by content hash within a session via `--photo-cache`).

## `locate-photo` — EXIF GPS extraction (no logging)

```bash
python3 .../food_log.py locate-photo --photo /mnt/user-data/uploads/<file>
```

Returns JSON with `status` ∈ `{found, ambiguous, no_poi, no_exif, no_pillow, error}`. See main `SKILL.md` "Photo location flow" for branching logic.

## `recent` — Show recent entries

```bash
python3 .../food_log.py recent --limit 10
```

Returns the last N rows as JSON. Useful for sanity checks and finding row numbers for `delete` / `update`.

## `delete` — Delete a row

```bash
python3 .../food_log.py delete --row 42
```

Row numbers are 1-indexed; header is row 1, so the first data row is row 2.

## `update` — Update one cell

```bash
python3 .../food_log.py update --row 42 --column "Calories" --value 520
```

`--column` must match a header name exactly. Run `headers` first if unsure.

## `headers` — Show current column headers

```bash
python3 .../food_log.py headers
```

Useful before `update` to confirm column names.

## `stats` — Aggregate over a date range

```bash
python3 .../food_log.py stats --days 30
python3 .../food_log.py stats --since 2026-04-01 --until 2026-04-30
```

Used by the `food-history` skill (not directly by `food-log`). See that skill's SKILL.md for details on the output structure.

## `setup-check` — Verify auth & sheet access

```bash
python3 .../food_log.py setup-check
```

Confirms OAuth token works, sheet is reachable, and Drive folder exists. Useful for debugging or after config changes.

## `auth-url` / `auth-code` — One-time OAuth setup

See `references/setup.md`.
