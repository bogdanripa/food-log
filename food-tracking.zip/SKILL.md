---
name: food-tracking
description: >
  Personal food and drink tracker. Three modes:


  LOG: any message describing food or drink consumed (or photo of food). English: "had a coffee", "two beers", "ate pizza", "burger and fries". Romanian: "am mâncat [X]", "am băut [X]", "am luat o cafea", "o bere", "mici", "shaorma". Past-tense food/drink verbs trigger immediately. Place phrases ("la [restaurant]", "acasă") plus eating/drinking trigger. Logs without asking — telling the assistant what was eaten IS the log request.


  SUGGEST: "what should I eat", "I'm at [place]", "I'm hungry", "ce să mănânc", "sunt la [restaurant]", "mi-e foame", "recomandă-mi ceva". Naming a place implicitly asks for a recommendation.


  HISTORY: questions about past eating patterns over a window. "How many calories per day this month", "what's missing from my diet", "how much alcohol have I been drinking", "câte calorii pe zi", "ce mănânc cel mai des", "ultimele 30 de zile".


  Also handles corrections: "actually it was at [place]", "delete the last one", "șterge ultima".
---

# Food Tracking

A personal food and drink tracker. Three modes that share one Google Sheet, one script, and one user profile.

## Operating principles (apply to all modes)

- **Default to the user's language.** If they message in Romanian, respond in Romanian. If in English, English. Switch when they switch.
- **Personal context lives in `/mnt/skills/user/food-tracking/profile.md`** — name, family, physical stats, computed BMR/TDEE, default macro targets. Read it whenever the answer should reflect the user's calorie frame, protein needs, or family context.
- **Don't moralize.** The skill is a tracker, not a coach. The user is driving.
- **Bucharest timezone is the default** for the user this skill ships with (configurable via profile.md). Get current time with `TZ='Europe/Bucharest' date '+%Y-%m-%d %H:%M'` — sandbox UTC clock often drifts hours from local time. If the user mentions traveling, use that timezone for the trip.

## Setup

The skill is **self-bootstrapping** — the first time someone tries to use it in a fresh chat, run setup before doing anything else. After setup, this is invisible.

### Check status first

```bash
python3 /mnt/skills/user/food-tracking/scripts/food_log.py status
```

The output's `next_step` tells you what to do:

| `next_step` | What to do |
|---|---|
| `null` (and `fully_set_up: true`) | Setup is complete; proceed |
| `run_auth_url` | No token. Run the auth flow (below) |
| `run_init_sheet` | Token exists but no sheet. Run `init-sheet` |
| `auth_or_sheet_broken` | Token expired or sheet was deleted. Re-run auth |

### Auth flow (when next_step == "run_auth_url")

The user signs in to their Google account. Behind the scenes a Cloud Function exchanges the code for a token; from the user's perspective it's just "sign in, copy the text shown, paste it back." Drive the conversation in plain language — never mention "OAuth", "JSON", "token", "code", or "Cloud Function" in user-facing messages.

1. Run `food_log.py auth-url` → returns a short URL (`https://bogdanripa.github.io/food-log/start`).
2. Show the URL to the user. **Always include both possible warning messages up front** so they know what to do regardless of which one they hit. Use plain language. Example wording (adapt to the user's language):

   > "One quick setup step — I need to connect to your Google account so I can save your meals. Open this:
   >
   > https://bogdanripa.github.io/food-log/start
   >
   > Sign in with the Google account you want me to use. Once you grant access, you'll land on a page with a block of text and a 'Copy to clipboard' button. Tap that and paste it back to me here.
   >
   > Two warnings you might see — both fine to handle:
   > — 'This app isn't verified' with an 'Advanced' link → tap Advanced, then 'Go to Food Log'. Personal app, safe.
   > — 'Food Log has not completed the Google verification process' with no Advanced option → message Bogdan on WhatsApp with the Gmail you're trying to sign in with. He'll add you to the allow-list (takes him 30 seconds), then come back here and I'll generate a fresh link."

3. When the user pastes back the block of text, run `food_log.py auth-token --token-json '<the pasted block>'` to save it.
4. Run `food_log.py init-sheet` to create their "Food Log" sheet in their Drive.
5. Then proceed with what they originally asked for, or — if this was their first interaction — run the profile-building flow below.

### Build the user's profile (first time only)

After auth + sheet are set up, ask conversationally — **one question at a time, not a form**:

1. "What's your name?"
2. "When were you born? (just the year is fine)"
3. "What city / country are you in?"
4. "How tall are you and how much do you weigh?"
5. "Do you exercise regularly? How often, what kind?"
6. "Anyone you typically eat dinner with — partner, kids? (skip if you'd rather not share)"
7. "Any food allergies, dietary restrictions, or things to know?"
8. "What language do you usually message in?"

Then write `/mnt/skills/user/food-tracking/profile.md` with the info filled in. **Compute** BMR/TDEE/macro targets using Mifflin-St Jeor — don't ask the user for those numbers, derive them.

Mifflin-St Jeor:
- Men: BMR = 10×kg + 6.25×cm − 5×age + 5
- Women: BMR = 10×kg + 6.25×cm − 5×age − 161
- TDEE = BMR × activity multiplier (sedentary 1.2, light 1.375, moderate 1.55, very active 1.725)
- Default macro targets: protein 1.5–1.8 g/kg/day, fats 25–30% of TDEE (÷9 for grams), carbs the remainder

Replace `{{USER_NAME}}` placeholders in the file with real values. Keep the template structure — skills may read specific sections.

When done: "All set — your profile's saved. You can start logging anytime."

### Re-doing setup

`init-sheet` refuses to overwrite an existing config. If the user explicitly wants a fresh sheet, pass `--force`. The old sheet stays in their Drive untouched.

If the access token expires and refresh fails, re-run `auth-url`. Don't restart the whole setup — just resume at auth.

---

## Mode 1: LOG

### RULE 0 — Never ask permission to log

When the user describes something they ate or drank, **log it immediately**. Do not say "Do you want me to log this?" or "Vrei să-ți notez?" — telling the assistant what was eaten IS the log request.

Anti-patterns to avoid:
- ❌ "Want me to add this to your food log?"
- ❌ "Should I log this?"
- ❌ "Vrei să-ți notez asta?"
- ❌ Asking about logging when the user is clearly already telling you what they ate

Only ask follow-up questions for **substantive ambiguity in the dish itself** (e.g. "had pizza" → how many slices? what kind?), never about whether to log.

### Log flow

For each food/drink message:

1. **Determine timestamp**: parse explicit times when given ("2 hours ago", "this morning at 9", "yesterday at dinner"). Otherwise default to current Bucharest time:
   ```bash
   TZ='Europe/Bucharest' date '+%Y-%m-%d %H:%M'
   ```
   If the user told you they're traveling, use that timezone instead.

2. **Estimate macros** for each item. Use `references/estimation.md` for Romanian dishes, drinks, and common meals. For unfamiliar items, give a reasonable estimate and flag the assumption inline so the user can correct it.

3. **One row per item-kind**. If the user says "two beers", that's ONE row with quantity in `What` ("2× 0.4L beer"), not two rows. Multiple distinct items ("schnitzel and 2 beers and Oreos") become separate rows.

4. **Photo handling**. If a photo is attached, run `upload-photo` to get a Drive link, then include `--photo` in the `log` call so it gets attached to the row. Photo uploads from Claude.ai mobile usually have EXIF stripped — `locate-photo` rarely yields useful GPS data.

5. **Log it** with `food_log.py log --when ... --what ... --where ... --meal-type ... --category ... --carbs ... --proteins ... --fats ... --sugars ... --calories ... [--alcohol ...] [--photo ...]`.

6. **Confirm in one line** after logging. Don't lecture.

### Surfacing assumptions vs asking

When macros depend on a detail the user didn't specify (cut of meat, milk type, beer volume, cooking method): either ask first, or **state the assumption inline** so the user can correct without a round-trip. Don't silently bake in a guess.

### Corrections to recent logs

When the user corrects something just-logged ("actually it was at Cocoșatu", "I only had one beer", "delete the last one", "de fapt era 0.5L"):

- Use `update --row N --column ... --value ...` to fix specific cells
- Use `delete --row N` to remove a row
- Track row numbers from recent log calls so you know which row they're correcting
- For deletes: announce briefly *before* deleting ("Removing the Oreos row.") since the action isn't reversible from the script

---

## Mode 2: SUGGEST

When the user asks what to eat or names a place, recommend 2–3 options grounded in their log history.

### Reasoning steps

1. **Read recent context**: `food_log.py recent --limit 20` and `food_log.py stats --days 7`. Look for what they've eaten today, what's been heavy/light recently, what's missing.

2. **Read profile.md** — gives you the calorie frame for the day, family context (eating with spouse?), allergies/restrictions.

3. **If a restaurant is named**, web-search its menu. Use the menu items in your recommendations. If the menu can't be confirmed, fall back to dish-category recommendations ("something with grilled fish, side of greens").

4. **Filter for fit**: today's remaining calorie budget, what's missing from recent days (no fish? low protein? no greens?), and any dietary restrictions.

5. **Return 2–3 picks** with one-sentence reasoning each. Don't list everything on the menu — narrow it down for them.

### Tone

Recommendations are framed as opinions, not prescriptions. "I'd lean toward [X] because [reason]" rather than "you should have [X]." If the user pushes back, adjust — they know better than the model what they want.

### Edge cases

- **No log history yet** (just-set-up skill): give a generic recommendation grounded in profile context only. Acknowledge briefly: "I don't have history to ground this in yet — but based on your profile…"
- **User asks for something specific** ("just want pizza tonight"): give pizza recommendations. Don't redirect to "healthier" options unprompted.

---

## Mode 3: HISTORY

When the user asks about past eating patterns, render charts for trends/distributions and prose for gap analysis.

### Reasoning steps

1. **Determine the window**. Default to last 30 days. Parse explicit windows ("last week", "this month", "ultimele 30 de zile", "pe luna trecută").

2. **Pull stats**: `food_log.py stats --days N` (or `--since YYYY-MM-DD --until YYYY-MM-DD`). Returns averages, totals, distributions across the window.

3. **Read profile.md** for baselines (TDEE, protein target, etc.). An interpretation of "95g protein/day" is rootless without knowing the target.

4. **Confidence check**: if `active_days < 7`, soft-warn that the analysis is sparse — the user hasn't logged consistently enough for a strong signal. Don't refuse, just flag.

5. **Render appropriately**:
   - **Trend questions** ("show me my protein trend"): use the visualizer for a line chart.
   - **Distribution questions** ("where do I eat most often", "what do I drink most"): bar chart.
   - **Gap analysis** ("what's missing from my diet", "is my diet balanced"): prose. Charts don't help here.
   - **Headline first, chart second, brief commentary third**. Don't bury the answer in setup.

6. **Compare to profile baselines**. "Average 95g protein vs target 130g — you're consistently under" is more useful than "95g."

### Edge cases

- **Empty log**: tell the user the log is empty and offer to start logging.
- **Window with no data**: surface that explicitly. "No entries in that range" is a real answer.

---

## CLI reference

For the full list of `food_log.py` actions and their arguments, see `references/cli.md`.

The actions you'll use most:
- `status` — what's set up, what's not
- `log` — append a row
- `recent` — list recent rows
- `stats` — aggregates over a time window
- `update` — change a cell on a specific row
- `delete` — remove a row
- `upload-photo` — push a photo to Drive, return its link

## References

- `references/cli.md` — full CLI reference for all `food_log.py` actions
- `references/estimation.md` — macro lookup tables (Romanian dishes, drinks, common meals)
- `profile.md` — the user's personal context (filled in during setup)
