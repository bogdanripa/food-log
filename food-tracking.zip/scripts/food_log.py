#!/usr/bin/env python3
"""
Food & Drink log — appends rows to the Google Sheet and uploads photos to Drive.

First-time auth flow:
  - Place client_secret.json in <skill-dir>/ (downloaded from Google Cloud Console)
  - Run any command; if no token.json exists, the script prints a URL for you to
    visit, paste the resulting code back, and saves token.json for future runs.
"""

import argparse
import hashlib
import json
import mimetypes
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# --- Google API imports ---
try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    from googleapiclient.errors import HttpError
    import httplib2
    import google_auth_httplib2
except ImportError:
    print("ERROR: Missing Google API libraries. Install with:", file=sys.stderr)
    print("  pip install --break-system-packages google-api-python-client google-auth-httplib2", file=sys.stderr)
    sys.exit(2)

# --- EXIF / geocoding (optional; degrades gracefully if Pillow missing) ---
try:
    from PIL import Image, ExifTags
    _PIL_AVAILABLE = True
except ImportError:
    _PIL_AVAILABLE = False

import urllib.request
import urllib.parse


# --- Constants ---
SKILL_DIR = Path(__file__).resolve().parent.parent
TOKEN_FILE = SKILL_DIR / "token.json"
CONFIG_FILE = SKILL_DIR / "config.json"

# OAuth client id is public; the client secret is held server-side in our Cloud Function.
# The function exchanges authorization codes for tokens and refreshes access tokens.
CLIENT_ID = "510005622541-5pivsv187k62dnu9vq2u0uvu9hrardbg.apps.googleusercontent.com"
REDIRECT_URI = "https://bogdanripa.github.io/food-log/auth-callback.html"
OAUTH_FUNCTION_URL = "https://europe-west1-food-log-494913.cloudfunctions.net/food-oauth"

SCOPES = [
    "https://www.googleapis.com/auth/drive.file",
]

SHEET_NAME = "Sheet1"  # default first tab; updated below if different
PHOTOS_FOLDER_NAME = "Food Log Photos"


def _load_spreadsheet_id():
    """Read the user's spreadsheet ID from config.json next to the skill folder.
    Falls back to env var FOOD_LOG_SPREADSHEET_ID. Returns None if not configured —
    callers that need the sheet should check and trigger setup or fail with a clear message."""
    cfg_path = SKILL_DIR / "config.json"
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text())
            if cfg.get("spreadsheet_id"):
                return cfg["spreadsheet_id"]
        except (json.JSONDecodeError, OSError):
            pass
    env = os.environ.get("FOOD_LOG_SPREADSHEET_ID")
    if env:
        return env
    return None


def _require_spreadsheet_id():
    """Use in actions that must have a sheet — fails loudly with a setup hint."""
    sid = _load_spreadsheet_id()
    if sid is None:
        print(json.dumps({
            "ok": False,
            "error": "no_spreadsheet",
            "hint": "Sheet is not yet configured. Run `food_log.py init-sheet` to create one.",
        }, indent=2), file=sys.stderr)
        sys.exit(2)
    return sid


# Lazy-load: actual ID resolved on first use
SPREADSHEET_ID = None  # set by main() before any action runs

EXPECTED_HEADERS = [
    "When", "What", "Where", "Meal type", "Category",
    "Carbs", "Proteins", "Fats", "Sugars", "Calories", "Alcohol", "Photo",
]


# --- Auth ---
# This script runs in a cloud sandbox (no browser, no reachable localhost).
# Auth flow is two-step:
#   1) Run `auth-url`  → script prints a URL to open in your browser.
#   2) After auth, the browser lands on a GitHub Pages page that exchanges the code
#      via the Cloud Function and shows the token JSON to paste back.
#      Run `auth-token --token-json '<paste>'` → script saves the token.
# After that, all other commands work non-interactively (token auto-refreshes via the
# Cloud Function as well).


def _refresh_via_function(refresh_token):
    """Call the Cloud Function to exchange a refresh_token for a fresh access_token."""
    body = json.dumps({
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    }).encode("utf-8")
    req = urllib.request.Request(
        OAUTH_FUNCTION_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get_credentials():
    """Load credentials from token.json, refreshing via the Cloud Function if needed.
    Does NOT trigger interactive flow. First-time auth must be done via `auth-url`
    + `auth-token` actions."""
    if not TOKEN_FILE.exists():
        print(
            "ERROR: Not authenticated yet. Run:\n"
            f"  python3 {__file__} auth-url\n"
            "...then follow the printed instructions.",
            file=sys.stderr,
        )
        sys.exit(2)

    raw = json.loads(TOKEN_FILE.read_text())
    access_token = raw.get("access_token")
    refresh_token = raw.get("refresh_token")
    expiry_str = raw.get("expiry")

    # Determine if the access token is expired (or close enough that we should refresh).
    needs_refresh = False
    if not access_token:
        needs_refresh = True
    else:
        try:
            # Token expiry can be ISO-8601 string ("2026-05-05T12:00:00Z" / "+00:00") or
            # a Unix-ms timestamp (Google's Node library uses expiry_date in ms).
            if expiry_str is None and "expiry_date" in raw:
                # ms epoch from Node googleapis library
                expiry_dt = datetime.fromtimestamp(
                    raw["expiry_date"] / 1000, tz=timezone.utc
                )
            elif isinstance(expiry_str, str):
                cleaned = expiry_str.replace("Z", "+00:00")
                expiry_dt = datetime.fromisoformat(cleaned)
                if expiry_dt.tzinfo is None:
                    expiry_dt = expiry_dt.replace(tzinfo=timezone.utc)
            else:
                # Unknown shape — refresh to be safe
                expiry_dt = datetime.now(timezone.utc) - timedelta(seconds=1)
            now = datetime.now(timezone.utc)
            # Refresh if expired or within 60s of expiring
            if expiry_dt <= now + timedelta(seconds=60):
                needs_refresh = True
        except Exception:
            needs_refresh = True

    if needs_refresh:
        if not refresh_token:
            print(
                "ERROR: Access token expired and no refresh_token available. "
                "Re-run `auth-url` to re-authenticate.",
                file=sys.stderr,
            )
            sys.exit(2)
        try:
            new_tokens = _refresh_via_function(refresh_token)
        except Exception as e:
            print(json.dumps({
                "ok": False,
                "error": "refresh_failed",
                "detail": str(e),
                "hint": "If this persists, re-run `auth-url` to re-authenticate.",
            }), file=sys.stderr)
            sys.exit(2)

        access_token = new_tokens.get("access_token") or access_token
        # Google often omits refresh_token on refresh; the function echoes it back, but defend anyway
        if new_tokens.get("refresh_token"):
            refresh_token = new_tokens["refresh_token"]
        # Compute new expiry from "expires_in" (seconds)
        expires_in = new_tokens.get("expires_in", 3600)
        new_expiry = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
        # Save back to token.json — preserve all keys, update access/refresh/expiry
        raw["access_token"] = access_token
        raw["refresh_token"] = refresh_token
        raw["expiry"] = new_expiry.isoformat()
        TOKEN_FILE.write_text(json.dumps(raw, indent=2))

    return Credentials(
        token=access_token,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=CLIENT_ID,
        client_secret=None,
        scopes=SCOPES,
    )


def get_services():
    creds = get_credentials()
    # Build an httplib2.Http that respects the system CA bundle (needed when running
    # behind a TLS-intercepting egress proxy, which sets SSL_CERT_FILE / REQUESTS_CA_BUNDLE).
    ca_bundle = (
        os.environ.get("SSL_CERT_FILE")
        or os.environ.get("REQUESTS_CA_BUNDLE")
        or "/etc/ssl/certs/ca-certificates.crt"
    )
    http_for_sheets = google_auth_httplib2.AuthorizedHttp(
        creds, http=httplib2.Http(ca_certs=ca_bundle)
    )
    http_for_drive = google_auth_httplib2.AuthorizedHttp(
        creds, http=httplib2.Http(ca_certs=ca_bundle)
    )
    sheets = build("sheets", "v4", http=http_for_sheets, cache_discovery=False)
    drive = build("drive", "v3", http=http_for_drive, cache_discovery=False)
    return sheets, drive


# --- Config (caches folder ID, etc.) ---
def load_config():
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


# --- Sheet helpers ---
def get_sheet_name(sheets):
    """Return the title of the first sheet tab in the spreadsheet."""
    meta = sheets.spreadsheets().get(spreadsheetId=SPREADSHEET_ID).execute()
    return meta["sheets"][0]["properties"]["title"]


def ensure_headers(sheets, sheet_name):
    """Make sure row 1 contains EXPECTED_HEADERS.
    - Empty sheet: write headers.
    - Headers match: no-op.
    - Headers are a strict subset of EXPECTED_HEADERS, in the same relative order:
      insert the missing columns at the right positions (preserving data below).
    - Headers are unrecognizable: bail loudly rather than corrupt data.
    """
    rng = f"'{sheet_name}'!1:1"
    result = sheets.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=rng
    ).execute()
    current = result.get("values", [[]])[0] if result.get("values") else []
    # Trim trailing empties
    while current and current[-1] == "":
        current.pop()

    if current == EXPECTED_HEADERS:
        return  # Already correct

    if not current:
        # Empty sheet — just write headers
        sheets.spreadsheets().values().update(
            spreadsheetId=SPREADSHEET_ID,
            range=rng,
            valueInputOption="RAW",
            body={"values": [EXPECTED_HEADERS]},
        ).execute()
        return

    # Migration: headers are non-empty but don't match. See if `current` is a
    # subsequence of EXPECTED_HEADERS (i.e. missing some columns but otherwise correct).
    missing = []  # list of (insert_col_index_0based, header_name)
    e_idx = 0
    for c_name in current:
        # Find c_name in EXPECTED starting at e_idx
        while e_idx < len(EXPECTED_HEADERS) and EXPECTED_HEADERS[e_idx] != c_name:
            missing.append((e_idx, EXPECTED_HEADERS[e_idx]))
            e_idx += 1
        if e_idx == len(EXPECTED_HEADERS):
            raise RuntimeError(
                f"Cannot migrate headers — current header '{c_name}' is not in EXPECTED_HEADERS "
                f"or is out of order. Current: {current!r}, expected: {EXPECTED_HEADERS!r}. "
                "Fix the sheet manually or update EXPECTED_HEADERS."
            )
        e_idx += 1
    # Anything still left in EXPECTED is missing at the end
    while e_idx < len(EXPECTED_HEADERS):
        missing.append((e_idx, EXPECTED_HEADERS[e_idx]))
        e_idx += 1

    if not missing:
        # Subsequence matched but the trailing emptiness check earlier removed
        # something. Just write the row as-is.
        sheets.spreadsheets().values().update(
            spreadsheetId=SPREADSHEET_ID,
            range=rng,
            valueInputOption="RAW",
            body={"values": [EXPECTED_HEADERS]},
        ).execute()
        return

    # Apply migration: insert columns from right to left so earlier indices stay valid.
    meta = sheets.spreadsheets().get(spreadsheetId=SPREADSHEET_ID).execute()
    sheet_id = meta["sheets"][0]["properties"]["sheetId"]
    requests = []
    for col_idx, header_name in sorted(missing, key=lambda x: -x[0]):
        requests.append({
            "insertDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "COLUMNS",
                    "startIndex": col_idx,
                    "endIndex": col_idx + 1,
                },
                "inheritFromBefore": False,
            }
        })
    sheets.spreadsheets().batchUpdate(
        spreadsheetId=SPREADSHEET_ID,
        body={"requests": requests},
    ).execute()
    # Now rewrite header row with the canonical names
    sheets.spreadsheets().values().update(
        spreadsheetId=SPREADSHEET_ID,
        range=rng,
        valueInputOption="RAW",
        body={"values": [EXPECTED_HEADERS]},
    ).execute()
    print(
        f"Migrated headers: inserted {[m[1] for m in missing]} into the sheet.",
        file=sys.stderr,
    )


# --- Drive: photo upload ---
def get_or_create_photos_folder(drive, cfg):
    """Return Drive folder ID for the photos folder. Creates if missing."""
    folder_id = cfg.get("photos_folder_id")
    if folder_id:
        try:
            drive.files().get(fileId=folder_id, fields="id, trashed").execute()
            return folder_id
        except HttpError:
            pass  # cached ID is stale; fall through to (re)create

    # Search for existing folder by name in root
    query = (
        f"name = '{PHOTOS_FOLDER_NAME}' and "
        f"mimeType = 'application/vnd.google-apps.folder' and "
        f"trashed = false"
    )
    res = drive.files().list(q=query, fields="files(id, name)", pageSize=1).execute()
    files = res.get("files", [])
    if files:
        folder_id = files[0]["id"]
    else:
        folder = drive.files().create(
            body={
                "name": PHOTOS_FOLDER_NAME,
                "mimeType": "application/vnd.google-apps.folder",
            },
            fields="id",
        ).execute()
        folder_id = folder["id"]

    cfg["photos_folder_id"] = folder_id
    save_config(cfg)
    return folder_id


def upload_photo(drive, photo_path, folder_id, photo_cache=None):
    """
    Upload a photo to Drive folder, return shareable link.
    If photo_cache is given (a dict path) and the same file content was already
    uploaded in a previous call this session, reuse the link.
    """
    photo_path = Path(photo_path).resolve()
    if not photo_path.exists():
        raise FileNotFoundError(f"Photo not found: {photo_path}")

    # Hash for caching (also helps if same photo is sent twice in one chat)
    h = hashlib.sha256(photo_path.read_bytes()).hexdigest()[:16]

    cache = {}
    cache_file = None
    if photo_cache:
        cache_file = Path(photo_cache)
        if cache_file.exists():
            cache = json.loads(cache_file.read_text())
        if h in cache:
            return cache[h]

    mime, _ = mimetypes.guess_type(str(photo_path))
    mime = mime or "application/octet-stream"

    # Filename: timestamp + original name (so it sorts chronologically in Drive)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    drive_name = f"{ts}_{photo_path.name}"

    media = MediaFileUpload(str(photo_path), mimetype=mime, resumable=False)
    file = drive.files().create(
        body={"name": drive_name, "parents": [folder_id]},
        media_body=media,
        fields="id, webViewLink",
    ).execute()

    # Make the link viewable by anyone with the link
    drive.permissions().create(
        fileId=file["id"],
        body={"type": "anyone", "role": "reader"},
        fields="id",
    ).execute()

    link = file["webViewLink"]
    if cache_file is not None:
        cache[h] = link
        cache_file.write_text(json.dumps(cache))

    return link


# --- EXIF + reverse geocoding ---
USER_AGENT = "food-log-skill/1.0 (personal use)"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"


def _http_get_json(url, params=None, timeout=10):
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _http_post_json(url, data, timeout=15):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _exif_gps(photo_path):
    """Return (lat, lng) tuple if photo has GPS EXIF, else None."""
    if not _PIL_AVAILABLE:
        return None
    try:
        img = Image.open(photo_path)
    except Exception:
        return None
    # Pillow 6+ recommended path: getexif() returns IFD; GPS lives at tag GPSInfo.
    exif = img.getexif()
    if not exif:
        return None
    gps_ifd_tag = next(
        (t for t, n in ExifTags.TAGS.items() if n == "GPSInfo"), None
    )
    if gps_ifd_tag is None or gps_ifd_tag not in exif:
        return None
    gps_ifd = exif.get_ifd(gps_ifd_tag)
    if not gps_ifd:
        return None
    # Map numeric tags to GPS names
    gps = {ExifTags.GPSTAGS.get(k, k): v for k, v in gps_ifd.items()}

    def _to_deg(value):
        # value is a tuple of 3 rationals (deg, min, sec). In Pillow these come back
        # as IFDRational already convertible to float.
        d, m, s = (float(value[0]), float(value[1]), float(value[2]))
        return d + m / 60.0 + s / 3600.0

    try:
        lat = _to_deg(gps["GPSLatitude"])
        lng = _to_deg(gps["GPSLongitude"])
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return None
    if gps.get("GPSLatitudeRef", "N") in ("S", b"S"):
        lat = -lat
    if gps.get("GPSLongitudeRef", "E") in ("W", b"W"):
        lng = -lng
    return (lat, lng)


def _nominatim_reverse(lat, lng):
    """Reverse-geocode to a structured address. Returns dict or None."""
    try:
        return _http_get_json(NOMINATIM_URL, {
            "format": "json",
            "lat": f"{lat:.6f}",
            "lon": f"{lng:.6f}",
            "zoom": "18",
            "addressdetails": "1",
        })
    except Exception:
        return None


def _overpass_food_pois(lat, lng, radius_m=60):
    """Find restaurants/cafes/bars within radius. Returns list of {name, type, dist_m}."""
    q = (
        f"[out:json][timeout:10];"
        f"(node[amenity~'restaurant|cafe|bar|fast_food|pub|biergarten|food_court|ice_cream']"
        f"(around:{radius_m},{lat:.6f},{lng:.6f}););"
        f"out body;"
    )
    try:
        result = _http_post_json(OVERPASS_URL, {"data": q})
    except Exception:
        return []

    # Compute approx distance (haversine) for each
    import math
    def hav(lat1, lng1, lat2, lng2):
        R = 6371000
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dp = math.radians(lat2 - lat1)
        dl = math.radians(lng2 - lng1)
        a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
        return 2 * R * math.asin(math.sqrt(a))

    out = []
    for el in result.get("elements", []):
        tags = el.get("tags", {})
        name = tags.get("name")
        if not name:
            continue  # unnamed POI is useless to us
        out.append({
            "name": name,
            "type": tags.get("amenity", "?"),
            "dist_m": round(hav(lat, lng, el["lat"], el["lon"]), 1),
        })
    out.sort(key=lambda x: x["dist_m"])
    return out


def locate_from_photo(photo_path):
    """High-level: extract GPS from photo and resolve to a likely place.
    Returns a dict with `status` ∈ {no_pillow, no_exif, found, ambiguous, no_poi, error}.

    Confidence logic accounts for the fact that phone GPS can drift 30-80m in dense
    urban areas (tall buildings, indoor capture). We search at three radii:
      - inner (30m): if exactly one named POI -> "found", high confidence
      - mid   (80m): if one POI clearly closer than next -> "found", lower confidence
      - outer(80m): otherwise -> "ambiguous", show top candidates
    """
    if not _PIL_AVAILABLE:
        return {"status": "no_pillow",
                "message": "Pillow not installed; cannot read EXIF."}
    if not Path(photo_path).exists():
        return {"status": "error", "message": f"Photo not found: {photo_path}"}

    coords = _exif_gps(photo_path)
    if coords is None:
        return {"status": "no_exif",
                "message": "Photo has no GPS EXIF data (often stripped on share)."}

    lat, lng = coords
    addr = _nominatim_reverse(lat, lng) or {}
    address_str = addr.get("display_name", "")

    base = {
        "lat": round(lat, 6),
        "lng": round(lng, 6),
        "address": address_str,
    }

    # Search inner ring first
    inner = _overpass_food_pois(lat, lng, radius_m=30)
    if len(inner) == 1:
        top = inner[0]
        return {**base, "status": "found",
                "place": top["name"], "type": top["type"], "dist_m": top["dist_m"],
                "confidence": "high",
                "candidates": inner}

    # Expand to mid ring
    mid = _overpass_food_pois(lat, lng, radius_m=80)
    if not mid:
        return {**base, "status": "no_poi",
                "message": "GPS extracted but no named restaurants/cafes within 80m. "
                           "Likely a non-eating location (home, office, street)."}

    # If top candidate is much closer than runner-up, call it found (medium conf)
    if len(mid) == 1 or (mid[0]["dist_m"] < 15 and mid[1]["dist_m"] - mid[0]["dist_m"] >= 25):
        top = mid[0]
        return {**base, "status": "found",
                "place": top["name"], "type": top["type"], "dist_m": top["dist_m"],
                "confidence": "medium",
                "candidates": mid[:5]}

    # Otherwise: ambiguous — let the caller (Claude) ask the user
    return {**base, "status": "ambiguous",
            "candidates": mid[:5]}


def action_locate_photo(args):
    """CLI entrypoint to inspect EXIF location for a photo without logging anything."""
    result = locate_from_photo(args.photo)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def action_upload_photo(args):
    """Upload a photo to the Food Log Photos Drive folder and return its shareable link.
    Useful for attaching a photo to an existing row via `update --column Photo`."""
    _, drive = get_services()
    cfg = load_config()
    folder_id = get_or_create_photos_folder(drive, cfg)
    link = upload_photo(drive, args.photo, folder_id, args.photo_cache)
    print(json.dumps({"ok": True, "photo_link": link, "source": str(args.photo)}, indent=2))


def action_log(args):
    sheets, drive = get_services()
    sheet_name = get_sheet_name(sheets)
    ensure_headers(sheets, sheet_name)

    cfg = load_config()
    photo_link = ""
    if args.photo:
        folder_id = get_or_create_photos_folder(drive, cfg)
        photo_link = upload_photo(drive, args.photo, folder_id, args.photo_cache)

    when = args.when or datetime.now().strftime("%Y-%m-%d %H:%M")

    # Header-driven row construction so adding a column in EXPECTED_HEADERS is enough.
    values_by_header = {
        "When": when,
        "What": args.what,
        "Where": args.where or "",
        "Meal type": args.meal_type or "",
        "Category": args.category or "",
        "Carbs": args.carbs if args.carbs is not None else "",
        "Proteins": args.proteins if args.proteins is not None else "",
        "Fats": args.fats if args.fats is not None else "",
        "Sugars": args.sugars if args.sugars is not None else "",
        "Calories": args.calories if args.calories is not None else "",
        "Alcohol": args.alcohol if args.alcohol is not None else "",
        "Photo": photo_link,
    }
    row = [values_by_header[h] for h in EXPECTED_HEADERS]

    # Compute end column letter from header count (A=0, B=1, ...). Works up to 26 cols.
    end_col = chr(ord("A") + len(EXPECTED_HEADERS) - 1)

    # Insert at top: structurally insert a blank row at index 1 (= sheet row 2,
    # right under the headers), then write values into it.
    meta = sheets.spreadsheets().get(spreadsheetId=SPREADSHEET_ID).execute()
    sheet_id = meta["sheets"][0]["properties"]["sheetId"]
    sheets.spreadsheets().batchUpdate(
        spreadsheetId=SPREADSHEET_ID,
        body={"requests": [{
            "insertDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "ROWS",
                    "startIndex": 1,   # 0-indexed → sheet row 2
                    "endIndex": 2,
                },
                "inheritFromBefore": False,
            }
        }]},
    ).execute()

    rng = f"'{sheet_name}'!A2:{end_col}2"
    sheets.spreadsheets().values().update(
        spreadsheetId=SPREADSHEET_ID,
        range=rng,
        valueInputOption="USER_ENTERED",
        body={"values": [row]},
    ).execute()
    updated_range = f"'{sheet_name}'!A2:{end_col}2"
    print(json.dumps({
        "ok": True,
        "row": row,
        "updated_range": updated_range,
        "photo_link": photo_link,
    }, indent=2))


def action_recent(args):
    sheets, _ = get_services()
    sheet_name = get_sheet_name(sheets)
    end_col = chr(ord("A") + len(EXPECTED_HEADERS) - 1)
    rng = f"'{sheet_name}'!A:{end_col}"
    result = sheets.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=rng
    ).execute()
    rows = result.get("values", [])
    if not rows:
        print(json.dumps({"ok": True, "rows": []}, indent=2))
        return

    headers = rows[0]
    data = rows[1:]
    # Newest-on-top convention: data is already in reverse-chronological order in the sheet,
    # so "recent" = the first N data rows (rows 2..2+N-1 in 1-indexed sheet terms).
    recent = data[:args.limit]
    out = []
    for i, r in enumerate(recent):
        # Pad short rows
        r = r + [""] * (len(headers) - len(r))
        entry = dict(zip(headers, r))
        entry["_row"] = i + 2  # +2 because row 1 is header, data starts at row 2
        out.append(entry)
    print(json.dumps({"ok": True, "rows": out}, indent=2))


# --- Stats helpers ---
def _parse_when(s):
    """Parse a 'When' cell value into a datetime, or None if unparseable."""
    if not s:
        return None
    s = s.strip()
    # Try a few common formats produced by the log action and possible manual edits
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


def _to_float(v):
    """Coerce a sheet cell to float, returning 0.0 if it's empty or non-numeric.
    Sheet cells come back as strings; numeric ones may have commas (locale)."""
    if v is None or v == "":
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", ".").strip()
    try:
        return float(s)
    except ValueError:
        return 0.0


def action_stats(args):
    """Aggregate the food log over a date range. Returns a comprehensive JSON blob."""
    from collections import defaultdict, Counter

    sheets, _ = get_services()
    sheet_name = get_sheet_name(sheets)
    end_col = chr(ord("A") + len(EXPECTED_HEADERS) - 1)
    rng = f"'{sheet_name}'!A:{end_col}"
    result = sheets.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=rng
    ).execute()
    rows = result.get("values", [])
    if not rows or len(rows) < 2:
        print(json.dumps({"ok": True, "empty": True,
                          "message": "No log entries yet."}, indent=2))
        return

    headers = rows[0]
    data = rows[1:]

    # Resolve date range
    now = datetime.now()
    if args.since:
        since = _parse_when(args.since)
        if since is None:
            print(json.dumps({"ok": False, "error": f"Could not parse --since '{args.since}'. Use YYYY-MM-DD."}), file=sys.stderr)
            sys.exit(1)
    else:
        from datetime import timedelta
        since = now - timedelta(days=args.days)
        # Anchor at midnight of that day for inclusive day buckets
        since = since.replace(hour=0, minute=0, second=0, microsecond=0)

    if args.until:
        until = _parse_when(args.until)
        if until is None:
            print(json.dumps({"ok": False, "error": f"Could not parse --until '{args.until}'. Use YYYY-MM-DD."}), file=sys.stderr)
            sys.exit(1)
        # Make until inclusive of the whole day
        until = until.replace(hour=23, minute=59, second=59)
    else:
        until = now

    # Parse rows into structured entries within range
    entries = []
    parse_failures = 0
    for r in data:
        r = r + [""] * (len(headers) - len(r))
        entry = dict(zip(headers, r))
        ts = _parse_when(entry.get("When", ""))
        if ts is None:
            parse_failures += 1
            continue
        if ts < since or ts > until:
            continue
        entries.append({
            "ts": ts,
            "date": ts.date().isoformat(),
            "what": entry.get("What", ""),
            "where": entry.get("Where", ""),
            "meal_type": (entry.get("Meal type", "") or "").lower().strip(),
            "category": (entry.get("Category", "") or "").lower().strip(),
            "carbs": _to_float(entry.get("Carbs")),
            "proteins": _to_float(entry.get("Proteins")),
            "fats": _to_float(entry.get("Fats")),
            "sugars": _to_float(entry.get("Sugars")),
            "calories": _to_float(entry.get("Calories")),
            "alcohol": _to_float(entry.get("Alcohol")),
        })

    if not entries:
        print(json.dumps({
            "ok": True,
            "empty": True,
            "range": {"since": since.isoformat(), "until": until.isoformat()},
            "total_rows_in_sheet": len(data),
            "parse_failures": parse_failures,
            "message": "No entries in this date range.",
        }, indent=2))
        return

    # --- Aggregations ---
    # Per-day totals
    by_day = defaultdict(lambda: {
        "calories": 0.0, "proteins": 0.0, "carbs": 0.0,
        "fats": 0.0, "sugars": 0.0, "alcohol_g": 0.0, "entries": 0,
    })
    for e in entries:
        d = by_day[e["date"]]
        d["calories"] += e["calories"]
        d["proteins"] += e["proteins"]
        d["carbs"] += e["carbs"]
        d["fats"] += e["fats"]
        d["sugars"] += e["sugars"]
        d["alcohol_g"] += e["alcohol"]
        d["entries"] += 1

    # Sort days chronologically
    days_sorted = sorted(by_day.keys())
    per_day = [{"date": d, **{k: round(v, 1) for k, v in by_day[d].items()}}
               for d in days_sorted]

    # Days with any data (denominator for "average per active day")
    n_active_days = len(per_day)
    # Span from first to last day inclusive (denominator for "average per calendar day")
    if n_active_days > 0:
        first_d = datetime.fromisoformat(days_sorted[0])
        last_d = datetime.fromisoformat(days_sorted[-1])
        n_calendar_days = (last_d - first_d).days + 1
    else:
        n_calendar_days = 0

    def _sum(field):
        return sum(e[field] for e in entries)

    totals = {
        "calories": round(_sum("calories"), 1),
        "proteins": round(_sum("proteins"), 1),
        "carbs": round(_sum("carbs"), 1),
        "fats": round(_sum("fats"), 1),
        "sugars": round(_sum("sugars"), 1),
        "alcohol_g": round(_sum("alcohol"), 1),
        "entries": len(entries),
    }

    averages_per_active_day = {
        k: round(v / n_active_days, 1) if n_active_days else 0
        for k, v in totals.items() if k != "entries"
    }
    averages_per_calendar_day = {
        k: round(v / n_calendar_days, 1) if n_calendar_days else 0
        for k, v in totals.items() if k != "entries"
    }

    # Category & meal-type distributions (counts of entries)
    category_counts = Counter(e["category"] for e in entries if e["category"])
    meal_type_counts = Counter(e["meal_type"] for e in entries if e["meal_type"])
    where_counts = Counter(e["where"] for e in entries if e["where"])

    # Days since last instance of each category (for "missing" detection)
    last_seen_by_category = {}
    today = now.date()
    for e in entries:
        cat = e["category"]
        if not cat:
            continue
        if cat not in last_seen_by_category or e["ts"].date() > last_seen_by_category[cat]:
            last_seen_by_category[cat] = e["ts"].date()
    days_since_category = {
        cat: (today - d).days for cat, d in last_seen_by_category.items()
    }

    # Alcohol — grams of pure ethanol is the precise metric; entry count is supplementary
    alcohol_categories = {"beer", "wine", "spirits"}
    alcohol_entries = [e for e in entries if e["category"] in alcohol_categories or e["alcohol"] > 0]
    total_alcohol_g = sum(e["alcohol"] for e in entries)
    weeks = max(n_calendar_days / 7.0, 1.0 / 7.0) if n_calendar_days else 1
    alcohol_g_per_week = round(total_alcohol_g / weeks, 1) if n_calendar_days else 0
    alcohol_entries_per_week = round(len(alcohol_entries) / weeks, 1) if n_calendar_days else 0
    # WHO standard units (10g ethanol each) — handy for casual reading
    who_units_per_week = round(alcohol_g_per_week / 10.0, 1)

    # Drink vs. food entries
    drink_categories = {"beer", "wine", "spirits", "coffee", "tea",
                        "soft drink", "water", "juice", "smoothie"}
    n_drinks = sum(1 for e in entries if e["category"] in drink_categories)
    n_food = len(entries) - n_drinks

    # Top dishes (by frequency in the What column)
    what_counts = Counter(e["what"].strip() for e in entries if e["what"].strip())
    top_dishes = what_counts.most_common(10)

    # Build the output
    out = {
        "ok": True,
        "range": {
            "since": since.strftime("%Y-%m-%d"),
            "until": until.strftime("%Y-%m-%d"),
            "active_days": n_active_days,
            "calendar_days_span": n_calendar_days,
        },
        "data_quality": {
            "total_entries": len(entries),
            "rows_outside_range": len(data) - len(entries) - parse_failures,
            "rows_with_unparseable_when": parse_failures,
            # Soft warning: < 7 active days of data
            "low_confidence": n_active_days < 7,
        },
        "totals": totals,
        "averages_per_active_day": averages_per_active_day,
        "averages_per_calendar_day": averages_per_calendar_day,
        "per_day": per_day,
        "category_counts": dict(category_counts.most_common()),
        "meal_type_counts": dict(meal_type_counts.most_common()),
        "where_counts": dict(where_counts.most_common(10)),
        "days_since_category": days_since_category,
        "drinks_vs_food": {"food_entries": n_food, "drink_entries": n_drinks},
        "alcohol": {
            "entries": len(alcohol_entries),
            "entries_per_week": alcohol_entries_per_week,
            "total_g_ethanol": round(total_alcohol_g, 1),
            "g_per_week": alcohol_g_per_week,
            "who_units_per_week": who_units_per_week,
        },
        "top_dishes": [{"what": w, "count": c} for w, c in top_dishes],
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))


def action_delete(args):
    sheets, _ = get_services()
    meta = sheets.spreadsheets().get(spreadsheetId=SPREADSHEET_ID).execute()
    sheet = meta["sheets"][0]
    sheet_id = sheet["properties"]["sheetId"]
    # deleteDimension uses 0-indexed exclusive ranges
    sheets.spreadsheets().batchUpdate(
        spreadsheetId=SPREADSHEET_ID,
        body={
            "requests": [{
                "deleteDimension": {
                    "range": {
                        "sheetId": sheet_id,
                        "dimension": "ROWS",
                        "startIndex": args.row - 1,
                        "endIndex": args.row,
                    }
                }
            }]
        },
    ).execute()
    print(json.dumps({"ok": True, "deleted_row": args.row}, indent=2))


def action_update(args):
    sheets, _ = get_services()
    sheet_name = get_sheet_name(sheets)
    # Find column index by header name
    hdr = sheets.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=f"'{sheet_name}'!1:1"
    ).execute().get("values", [[]])[0]
    if args.column not in hdr:
        print(json.dumps({"ok": False, "error": f"Column '{args.column}' not found. Available: {hdr}"}), file=sys.stderr)
        sys.exit(1)
    col_idx = hdr.index(args.column)
    col_letter = chr(ord("A") + col_idx)
    cell = f"'{sheet_name}'!{col_letter}{args.row}"
    sheets.spreadsheets().values().update(
        spreadsheetId=SPREADSHEET_ID,
        range=cell,
        valueInputOption="USER_ENTERED",
        body={"values": [[args.value]]},
    ).execute()
    print(json.dumps({"ok": True, "cell": cell, "value": args.value}, indent=2))


def action_headers(args):
    sheets, _ = get_services()
    sheet_name = get_sheet_name(sheets)
    hdr = sheets.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=f"'{sheet_name}'!1:1"
    ).execute().get("values", [[]])[0]
    print(json.dumps({"ok": True, "sheet": sheet_name, "headers": hdr}, indent=2))


def action_status(args):
    """Report which setup steps have been completed. Used by skill instructions
    to decide whether to run setup. Does not require the sheet to exist yet."""
    has_token = TOKEN_FILE.exists()
    has_sheet_id = _load_spreadsheet_id() is not None

    sheet_ok = False
    sheet_url = None
    sheet_title = None
    auth_error = None
    if has_token and has_sheet_id:
        try:
            sheets, _ = get_services()
            meta = sheets.spreadsheets().get(spreadsheetId=_load_spreadsheet_id()).execute()
            sheet_title = meta.get("properties", {}).get("title", "")
            sheet_url = f"https://docs.google.com/spreadsheets/d/{_load_spreadsheet_id()}/edit"
            sheet_ok = True
        except Exception as e:
            auth_error = str(e)

    fully_set_up = has_token and has_sheet_id and sheet_ok

    next_step = None
    if not has_token:
        next_step = "run_auth_url"
    elif not has_sheet_id:
        next_step = "run_init_sheet"
    elif not sheet_ok:
        next_step = "auth_or_sheet_broken"

    print(json.dumps({
        "ok": True,
        "fully_set_up": fully_set_up,
        "has_token": has_token,
        "has_sheet_id": has_sheet_id,
        "sheet_accessible": sheet_ok,
        "sheet_title": sheet_title,
        "sheet_url": sheet_url,
        "next_step": next_step,
        "auth_error": auth_error,
    }, indent=2))


def action_init_sheet(args):
    """Create a new Google Sheet, save its ID to config.json, and write headers.
    Requires auth to be already done (token.json exists)."""
    if not TOKEN_FILE.exists():
        print(json.dumps({
            "ok": False,
            "error": "not_authenticated",
            "hint": "Run `auth-url` and `auth-token` first to authenticate, then re-run `init-sheet`.",
        }), file=sys.stderr)
        sys.exit(2)

    # Don't overwrite an existing config — bail with a clear message
    existing = _load_spreadsheet_id()
    if existing and not args.force:
        print(json.dumps({
            "ok": False,
            "error": "already_configured",
            "spreadsheet_id": existing,
            "hint": "A spreadsheet is already configured. Pass --force to create a new one (the old one stays in your Drive untouched).",
        }), file=sys.stderr)
        sys.exit(2)

    creds = get_credentials()
    # Build sheets service; we need just creation here, then ensure_headers will run on first log
    ca_bundle = (
        os.environ.get("SSL_CERT_FILE")
        or os.environ.get("REQUESTS_CA_BUNDLE")
        or "/etc/ssl/certs/ca-certificates.crt"
    )
    http = google_auth_httplib2.AuthorizedHttp(creds, http=httplib2.Http(ca_certs=ca_bundle))
    sheets = build("sheets", "v4", http=http, cache_discovery=False)

    title = args.title or "Food Log"
    body = {
        "properties": {"title": title},
        "sheets": [{"properties": {"title": "Sheet1"}}],
    }
    result = sheets.spreadsheets().create(body=body, fields="spreadsheetId,spreadsheetUrl").execute()
    new_id = result["spreadsheetId"]
    new_url = result["spreadsheetUrl"]

    # Save to config.json (preserving any other keys like photos_folder_id)
    cfg = load_config()
    cfg["spreadsheet_id"] = new_id
    save_config(cfg)

    # Now write the headers so the sheet is ready to use
    global SPREADSHEET_ID
    SPREADSHEET_ID = new_id
    try:
        # Fresh services with the now-set SPREADSHEET_ID for ensure_headers
        sheets2, _ = get_services()
        ensure_headers(sheets2, "Sheet1")
    except Exception as e:
        # The sheet was created successfully even if header-write hiccups; still report success
        print(json.dumps({
            "ok": True,
            "spreadsheet_id": new_id,
            "spreadsheet_url": new_url,
            "title": title,
            "warning": f"Sheet created but header initialization failed: {e}. It will retry on first log.",
        }, indent=2))
        return

    print(json.dumps({
        "ok": True,
        "spreadsheet_id": new_id,
        "spreadsheet_url": new_url,
        "title": title,
    }, indent=2))


def action_setup_check(args):
    """Verify auth + sheet access. Useful for debugging."""
    sheets, drive = get_services()
    sheet_name = get_sheet_name(sheets)
    cfg = load_config()
    folder_id = get_or_create_photos_folder(drive, cfg)
    print(json.dumps({
        "ok": True,
        "sheet_name": sheet_name,
        "spreadsheet_id": SPREADSHEET_ID,
        "photos_folder_id": folder_id,
        "token_exists": TOKEN_FILE.exists(),
    }, indent=2))


def action_auth_url(args):
    """Print the short URL the user must visit to grant OAuth access.

    The user opens the short URL → it redirects to Google → user signs in →
    Google redirects to the GitHub Pages auth-callback page → that page exchanges
    the code via the Cloud Function and shows the token to paste back. The user
    then runs `auth-token --token-json` to save it locally.
    """
    short_url = "https://bogdanripa.github.io/food-log/start"
    print(json.dumps({
        "ok": True,
        "auth_url": short_url,
        "instructions": (
            "Show the auth_url to the user. They open it, sign in, and the page "
            "they land on will display a block of text for them to copy back. "
            "Then run: food_log.py auth-token --token-json '<paste the block>'"
        ),
    }, indent=2))


def action_auth_token(args):
    """Save a pasted token JSON to token.json. The JSON comes from the auth-callback
    page on GitHub Pages, which exchanged the auth code via the Cloud Function."""
    if not args.token_json:
        print(json.dumps({"ok": False, "error": "Provide --token-json"}), file=sys.stderr)
        sys.exit(1)

    try:
        data = json.loads(args.token_json)
    except json.JSONDecodeError as e:
        print(json.dumps({
            "ok": False,
            "error": "invalid_json",
            "detail": str(e),
            "hint": "Paste the full token JSON exactly as shown on the auth-callback page, including the curly braces.",
        }), file=sys.stderr)
        sys.exit(1)

    if not data.get("access_token"):
        print(json.dumps({
            "ok": False,
            "error": "missing_access_token",
            "hint": "The pasted JSON does not contain an access_token. Run auth-url again and try the flow once more.",
        }), file=sys.stderr)
        sys.exit(1)

    if not data.get("refresh_token"):
        # Not a hard fail, but warn — the skill won't be able to refresh and will need re-auth in 1hr
        warning = "Pasted JSON has no refresh_token; the skill will need re-auth when the access token expires (~1hr)."
    else:
        warning = None

    # Normalize expiry: prefer ISO string. If we got expiry_date (ms epoch from Node lib), convert.
    if "expiry" not in data:
        if "expiry_date" in data:
            try:
                exp_dt = datetime.fromtimestamp(data["expiry_date"] / 1000, tz=timezone.utc)
                data["expiry"] = exp_dt.isoformat()
            except Exception:
                pass
        elif "expires_in" in data:
            exp_dt = datetime.now(timezone.utc) + timedelta(seconds=data["expires_in"])
            data["expiry"] = exp_dt.isoformat()

    TOKEN_FILE.write_text(json.dumps(data, indent=2))

    out = {
        "ok": True,
        "token_saved_to": str(TOKEN_FILE),
        "has_refresh_token": bool(data.get("refresh_token")),
    }
    if warning:
        out["warning"] = warning
    print(json.dumps(out, indent=2))


# --- CLI ---
def main():
    p = argparse.ArgumentParser(description="Food & Drink log tool")
    sub = p.add_subparsers(dest="action", required=True)

    # log
    sp = sub.add_parser("log", help="Append a row")
    sp.add_argument("--when", help="YYYY-MM-DD HH:MM (defaults to now)")
    sp.add_argument("--what", required=True, help="What was eaten/drunk")
    sp.add_argument("--where", help="Restaurant name, location, or 'home'. Optional.")
    sp.add_argument("--meal-type", help="breakfast / lunch / dinner / snack / drink / dessert")
    sp.add_argument("--category", help="salad / main course / beer / coffee / etc.")
    sp.add_argument("--carbs", type=float)
    sp.add_argument("--proteins", type=float)
    sp.add_argument("--fats", type=float)
    sp.add_argument("--sugars", type=float)
    sp.add_argument("--calories", type=float)
    sp.add_argument("--alcohol", type=float, help="Grams of pure ethanol (volume_ml × ABV × 0.789)")
    sp.add_argument("--photo", help="Path to photo file to upload")
    sp.add_argument("--photo-cache", help="Path to JSON cache for dedup'ing photo uploads in a session")
    sp.set_defaults(func=action_log)

    sp = sub.add_parser("recent", help="Show recent entries")
    sp.add_argument("--limit", type=int, default=10)
    sp.set_defaults(func=action_recent)

    sp = sub.add_parser("stats",
        help="Aggregate the log over a date range (totals, averages, distributions, gaps)")
    sp.add_argument("--days", type=int, default=30,
        help="How many days back from today (default 30). Ignored if --since is given.")
    sp.add_argument("--since", help="Start date (YYYY-MM-DD), inclusive")
    sp.add_argument("--until", help="End date (YYYY-MM-DD), inclusive. Defaults to now.")
    sp.set_defaults(func=action_stats)

    sp = sub.add_parser("delete", help="Delete a row by row number")
    sp.add_argument("--row", type=int, required=True)
    sp.set_defaults(func=action_delete)

    sp = sub.add_parser("update", help="Update one cell")
    sp.add_argument("--row", type=int, required=True)
    sp.add_argument("--column", required=True, help="Column header name")
    sp.add_argument("--value", required=True)
    sp.set_defaults(func=action_update)

    sp = sub.add_parser("headers", help="Show current column headers")
    sp.set_defaults(func=action_headers)

    sp = sub.add_parser("locate-photo",
        help="Extract GPS from photo EXIF and resolve to a likely place (does not log)")
    sp.add_argument("--photo", required=True, help="Path to photo file")
    sp.set_defaults(func=action_locate_photo)

    sp = sub.add_parser("upload-photo",
        help="Upload a photo to the Drive folder and return its link (does not log)")
    sp.add_argument("--photo", required=True, help="Path to photo file")
    sp.add_argument("--photo-cache", help="Optional dedup cache JSON path")
    sp.set_defaults(func=action_upload_photo)

    sp = sub.add_parser("setup-check", help="Verify auth & sheet access")
    sp.set_defaults(func=action_setup_check)

    sp = sub.add_parser("status",
        help="Report which setup steps are done. Returns next_step indicator.")
    sp.set_defaults(func=action_status)

    sp = sub.add_parser("init-sheet",
        help="Create a new Google Sheet in the user's Drive and save its ID")
    sp.add_argument("--title", help="Sheet title (default: 'Food Log')")
    sp.add_argument("--force", action="store_true",
        help="Re-init even if a sheet is already configured")
    sp.set_defaults(func=action_init_sheet)

    sp = sub.add_parser("auth-url", help="Print the OAuth URL to visit (first-time setup)")
    sp.set_defaults(func=action_auth_url)

    sp = sub.add_parser("auth-token",
        help="Save a pasted token JSON (from the auth-callback page) to token.json")
    sp.add_argument("--token-json", required=True,
        help="The full JSON object the auth-callback page displayed for paste-back")
    sp.set_defaults(func=action_auth_token)

    args = p.parse_args()
    # Actions that don't need a configured sheet (because they're part of setup
    # or report status without reading the sheet).
    SETUP_TIME_ACTIONS = ("auth-url", "auth-token", "init-sheet", "status")
    global SPREADSHEET_ID
    if args.action not in SETUP_TIME_ACTIONS:
        SPREADSHEET_ID = _require_spreadsheet_id()
    else:
        # Soft load — may be None, that's fine for these actions
        SPREADSHEET_ID = _load_spreadsheet_id()
    args.func(args)


if __name__ == "__main__":
    main()
